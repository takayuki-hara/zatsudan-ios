//
//  RestApiResponse.h
//  docomo-common-iso-sdk
//  (c) 2014 NTT DOCOMO, INC. All Rights Reserved.
//

#import <Foundation/Foundation.h>

@interface RestApiResponse : NSHTTPURLResponse

@end
